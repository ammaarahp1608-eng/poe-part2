import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class LoginTest {
    private Login login;

    @BeforeEach
    public void setUp() {
        login = new Login("Kyle", "LastName", "kyl_1", "Ch&&sec@ke99!", "+2783968976");
    }

    // --- assertEquals Tests ---

    @Test
    public void testUsernameCorrectlyFormattedMessage() {
        login.setUsername("kyl_1");
        boolean isValid = login.checkUserName();
        String expected = "Welcome Kyle,LastName it is great to see you.";
        String actual = login.returnLoginStatus(isValid);
        assertEquals(expected, actual);
    }

    @Test
    public void testUsernameIncorrectlyFormattedMessage() {
        login.setUsername("kyle!!!!!!");
        String expected = "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        String actual = login.registerUser();
        assertEquals(expected, actual);
    }

    @Test
    public void testPasswordMeetsComplexityMessage() {
        login.setPassword("Ch&&sec@ke99!");
        login.setUsername("kyl_1");
        login.setPhoneNumber("+2783968976");
        
        // Simulating single validation check return
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testPasswordDoesNotMeetComplexityMessage() {
        login.setPassword("password");
        login.setUsername("kyl_1");
        String expected = "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        String actual = login.registerUser();
        assertEquals(expected, actual);
    }

    @Test
    public void testCellPhoneCorrectlyFormattedMessage() {
        login.setPhoneNumber("+2783968976");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCellPhoneIncorrectlyFormattedMessage() {
        login.setPhoneNumber("08966553");
        login.setUsername("kyl_1");
        login.setPassword("Ch&&sec@ke99!");
        String expected = "Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.";
        String actual = login.registerUser();
        assertEquals(expected, actual);
    }

    // --- assertTrue / assertFalse Tests ---

    @Test
    public void testLoginSuccessful() {
        assertTrue(login.loginUser("kyl_1", "Ch&&sec@ke99!"));
    }

    @Test
    public void testLoginFailed() {
        assertFalse(login.loginUser("wrongUser", "wrongPass"));
    }

    @Test
    public void testUsernameCorrectlyFormatted() {
        assertTrue(login.checkUserName("kyl_1"));
    }

    @Test
    public void testUsernameIncorrectlyFormatted() {
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }

    @Test
    public void testPasswordMeetsComplexity() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testPasswordDoesNotMeetComplexity() {
        assertFalse(login.checkPasswordComplexity("password"));
    }

    @Test
    public void testCellPhoneCorrectlyFormatted() {
        assertTrue(login.checkCellPhoneNumber("+2783968976"));
    }

    @Test
    public void testCellPhoneIncorrectlyFormatted() {
        assertFalse(login.checkCellPhoneNumber("08966553"));
    }
}