import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login userLogin = new Login();

        System.out.println("=== USER REGISTRATION ===");
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        userLogin.setFirstName(firstName);

        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        userLogin.setLastName(lastName);

        // Username Input Loop
        String username;
        while (true) {
            System.out.print("Enter Username (must contain '_' and <= 5 chars): ");
            username = scanner.nextLine();
            userLogin.setUsername(username);
            if (userLogin.checkUserName()) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            }
        }

        // Password Input Loop
        String password;
        while (true) {
            System.out.print("Enter Password (>= 8 chars, 1 capital, 1 number, 1 special char): ");
            password = scanner.nextLine();
            userLogin.setPassword(password);
            if (userLogin.checkPasswordComplexity()) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            }
        }

        // Cell Phone Input Loop
        String phone;
        while (true) {
            System.out.print("Enter Cell Phone Number (e.g. +2783968976, max 10 chars): ");
            phone = scanner.nextLine();
            userLogin.setPhoneNumber(phone);
            if (userLogin.checkCellPhoneNumber()) {
                System.out.println("Cell number successfully captured.");
                break;
            } else {
                System.out.println("Cell number is incorrectly formatted or does not contain an international code; please correct the number and try again.");
            }
        }

        System.out.println("\n=== USER LOGIN ===");
        System.out.print("Enter Username: ");
        String loginUser = scanner.nextLine();

        System.out.print("Enter Password: ");
        String loginPass = scanner.nextLine();

        boolean isAuthenticated = userLogin.loginUser(loginUser, loginPass);
        System.out.println(userLogin.returnLoginStatus(isAuthenticated));

        scanner.close();
    }
}